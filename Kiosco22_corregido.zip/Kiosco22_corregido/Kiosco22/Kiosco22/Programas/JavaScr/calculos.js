// =========================================================
// VARIABLES GLOBALES
// =========================================================
let carrito = [];
let listaProductosBD = [];

// =========================================================
// USUARIO
function obtenerUsuario() {
    try {
        return JSON.parse(localStorage.getItem("usuario"));
    } catch {
        return null;
    }
}

function mostrarUsuario() {
    let user = obtenerUsuario();
    let box = document.getElementById("userBox");

    if (!box) return;

    if (user && user.nombre) {
        box.innerHTML = `
            <div style="display: flex; align-items: center; gap: 10px;">
                <span style="font-weight: bold; color: #000000; ">👤 ${user.nombre}</span>
            </div>
        `;
    } else {
        box.innerHTML = `<a href="Kios_login.html" style="text-decoration: none; font-size: 20px;">👤</a>`;
    }
}

function logout() {
    localStorage.removeItem("usuario");
    localStorage.removeItem("login_exitoso");
    window.location.href = "Kios_login.html";
}

function cargarProductosTienda() {
    fetch("/productos")
        .then(response => response.json())
        .then(productos => {
            listaProductosBD = productos;
            dibujarProductos(productos);
        })
        .catch(err => {
            console.error("Error al cargar productos:", err);
            document.getElementById("productos").innerHTML =
                "<p>Error al conectar con la tienda.</p>";
        });
}


function dibujarProductos(productos) {
    const contenedor = document.getElementById("productos");

    if (productos.length === 0) {
        contenedor.innerHTML = "<p>No hay productos</p>";
        return;
    }

    const agrupados = {};

    productos.forEach(p => {
        let cat = (p.categoria || 'Otros').toLowerCase().trim();
        if (!agrupados[cat]) agrupados[cat] = [];
        agrupados[cat].push(p);
    });

    let html = "";

    for (const categoria in agrupados) {

        html += `
        <section id="seccion-${categoria}" class="grupo-categoria">
            <h2>${categoria}</h2>
            <div class="contenedor-tarjetas">
        `;

        agrupados[categoria].forEach(p => {
            html += `
            <div class="caja">
                <img src="${p.imagen}">
                <h3>${p.nombre}</h3>
                <p class="precio">$${p.precio}</p>

                <div class="contador">
                    <button onclick="restar(this)">-</button>
                    <span class="cantidad">0</span>
                    <button onclick="sumar(this)">+</button>
                </div>

                <button class="btn-agregar"  onclick="agregarCarrito(this)">
                    Agregar
                </button>
            </div>
            `;
        });

        html += `</div></section>`;
    }

    contenedor.innerHTML = html;
}

function sumar(boton) {
    let span = boton.parentElement.querySelector('.cantidad');
    span.innerText = parseInt(span.innerText) + 1;
}

function restar(boton) {
    let span = boton.parentElement.querySelector('.cantidad');
    let cantidad = parseInt(span.innerText);
    if (cantidad > 0) span.innerText = cantidad - 1;
}

function agregarCarrito(boton) {
    let usuario = obtenerUsuario();

    if (!usuario) {
        alert("⚠️ Tenés que iniciar sesión para comprar");

        localStorage.setItem("redirect", "ventaspag2.html");
        window.location.href = "Kios_login.html";
        return;
    }

    let caja = boton.closest('.caja');

    let nombre = caja.querySelector('h3').innerText;
    let precio = parseFloat(
        caja.querySelector('.precio').innerText.replace('$', '')
    );
    let cantidad = parseInt(
        caja.querySelector('.cantidad').innerText
    );

    if (cantidad === 0) {
        alert("Selecciona al menos 1 unidad.");
        return;
    }

    let itemExistente = carrito.find(item => item.nombre === nombre);

    if (itemExistente) {
        itemExistente.cantidad += cantidad;
    } else {
        carrito.push({ nombre, precio, cantidad });
    }

    caja.querySelector('.cantidad').innerText = "0";

    actualizarBotonCarrito();

    alert(`Se agregaron ${cantidad}x ${nombre} al carrito.`);
}

function eliminarItem(index) {
    carrito.splice(index, 1);
    actualizarBotonCarrito();
    abrirFactura();
}

function actualizarBotonCarrito() {
    let total = 0;
    carrito.forEach(item => total += item.cantidad);

    let boton = document.querySelector('.btn-flotante');
    if (!boton) return;

    boton.innerText = total > 0
        ? `🛒 Ver Cuenta (${total})`
        : `🛒 Ver Cuenta`;
}


function cerrarFactura() {
    document.getElementById("miModal").style.display = "none";
}

function abrirFactura() {
    let lista = document.getElementById("lista-carrito");
    let spanTotal = document.getElementById("total");
    lista.innerHTML = ""; 
    let totalPrecio = 0;

    carrito.forEach((item, index) => {
        let subtotal = item.precio * item.cantidad;
        totalPrecio += subtotal;

        let li = document.createElement("li");
        li.innerHTML = `
            ${item.cantidad}x ${item.nombre} - $${subtotal} 
            <button onclick="eliminarItem(${index})">X</button>
        `;
        lista.appendChild(li);
    });

    spanTotal.innerText = totalPrecio;
    document.getElementById("miModal").style.display = "flex"; 
}



function generarPDF() {
    if (carrito.length === 0) {
        alert("La cuenta está en cero.");
        return;
    }

    const { jsPDF } = window.jspdf;
    
    const doc = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: [80, 150] 
    });

    doc.setFillColor(26, 26, 46); 
    doc.rect(0, 0, 80, 150, 'F');

    doc.setTextColor(255, 255, 255);
    doc.setFont("courier", "bold");
    doc.setFontSize(12);

    doc.text("COMPROBANTE", 40, 15, { align: "center" });
    doc.text("DE COMPRA", 40, 20, { align: "center" });

    doc.setFontSize(10);
    doc.setFont("courier", "normal");
    doc.setTextColor(150, 150, 150); 
    doc.text("--------------------------------", 40, 27, { align: "center" });

    let y = 35;
    let totalFinal = 0;

    doc.setTextColor(255, 255, 255); 

    carrito.forEach(item => {
        let subtotal = item.precio * item.cantidad;
        totalFinal += subtotal;

        let textoIzq = `${item.cantidad}x ${item.nombre}`;
        if (textoIzq.length > 15) {
            textoIzq = textoIzq.substring(0, 14) + ".";
        }

        doc.text(textoIzq, 5, y);
        
        doc.setTextColor(100, 100, 100);
        doc.text(".............", 38, y);
        doc.setTextColor(255, 255, 255);

        doc.text(`$${subtotal}`, 75, y, { align: "right" });
        
        y += 7; 
    });

    doc.setTextColor(150, 150, 150);
    doc.text("--------------------------------", 40, y + 2, { align: "center" });
    
    y += 10;
    doc.setFont("courier", "bold");
    doc.setFontSize(12);
    doc.setTextColor(255, 255, 255);
    doc.text("TOTAL", 5, y);
    doc.text(`$${totalFinal}`, 75, y, { align: "right" });

    // ─── TU FIRMA 
    y += 15;
    doc.setFontSize(10); // Letra un poco más grande
    doc.setFont("courier", "bolditalic"); // Fuente en negrita y cursiva
    doc.setTextColor(255, 0, 110); // Color fucsia neón (#FF006E)
    
    doc.text("Esto lo hizo Gemini Pro,", 40, y, { align: "center" });
    doc.text("no sé cómo se hace. Atte. Kevin", 40, y + 5, { align: "center" });

    doc.save("Ticket_Kiosco.pdf");
}
// =========================================================



document.addEventListener("DOMContentLoaded", () => {
    // Revisamos si venimos directo desde el formulario de login exitoso
    let vieneDeLogin = localStorage.getItem("login_exitoso");

    if (vieneDeLogin === "true") {
        // Si viene del login, NO lo borramos, solo gastamos el "ticket" para la próxima vez
        localStorage.removeItem("login_exitoso");
    } else {
        // Si entró escribiendo la URL de cero o cerró la pestaña y volvió, se limpia
        localStorage.removeItem("usuario");
    }

    mostrarUsuario(); 
    cargarProductosTienda();
});


function logout() {
    localStorage.removeItem("usuario");
   window.location.href = "Kios_login.html";
}

function filtrarPorCategoria(categoria) {

    if (categoria === 'todos') {
        document.getElementById("productos")
            .scrollIntoView({ behavior: "smooth" });
        return;
    }

    let catDestino = categoria.toLowerCase().trim();

   
    if (catDestino === 'snack') catDestino = 'snacks';
    if (catDestino === 'dulces') catDestino = 'golosinas';

    const elemento = document.getElementById(`seccion-${catDestino}`);

    if (elemento) {
        elemento.scrollIntoView({ behavior: "smooth" });
    } else {
        console.warn("No existe:", `seccion-${catDestino}`);
    }
}